import React from 'react';
import { DivideIcon as LucideIcon } from 'lucide-react';

interface FeatureCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
}

const FeatureCard: React.FC<FeatureCardProps> = ({ icon: Icon, title, description }) => {
  return (
    <div className="p-6 bg-white rounded-lg shadow-md border border-gray-100 transition-all duration-300 hover:shadow-lg hover:border-[#2073C7]/20">
      <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-[#2073C7]/10 text-[#2073C7] mb-4">
        <Icon size={20} />
      </div>
      <h3 className="text-xl font-bold mb-3">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  );
};

export default FeatureCard;