import React, { useState, useEffect } from 'react';
import { Menu, X } from 'lucide-react';
import Button from './ui/Button';

const Navbar: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMenuOpen(false);
  };

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
      isScrolled ? 'bg-white shadow-md py-2' : 'bg-transparent py-4'
    }`}>
      <div className="container mx-auto px-4 md:px-6 flex justify-between items-center">
        <div className="flex items-center">
          <span
  className="text-3xl font-extrabold tracking-tight text-[#329BFF] hover:scale-110 hover:brightness-110 transition-all duration-200 cursor-pointer"
>
  SellSmarter<span className="text-black">.ai</span>
</span>

        </div>

        {/* Desktop Navigation */}
        <div className="hidden md:flex items-center space-x-8">
          <button 
            onClick={() => scrollToSection('features')}
            className="font-medium hover:text-[#2073C7] transition-colors"
          >
            Services
          </button>
          <button 
            onClick={() => scrollToSection('process')}
            className="font-medium hover:text-[#2073C7] transition-colors"
          >
            Process
          </button>
          <button 
            onClick={() => scrollToSection('benefits')}
            className="font-medium hover:text-[#2073C7] transition-colors"
          >
            Benefits
          </button>
          <Button 
            onClick={() => scrollToSection('cta')}
            variant="primary"
            size="sm"
          >
            Book a Call
          </Button>
        </div>

        {/* Mobile Navigation Toggle */}
        <button 
          className="md:hidden focus:outline-none"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
        >
          {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden absolute top-full left-0 right-0 bg-white shadow-md p-4">
          <div className="flex flex-col space-y-4">
            <button 
              onClick={() => scrollToSection('features')}
              className="py-2 font-medium hover:text-[#2073C7] transition-colors"
            >
              Services
            </button>
            <button 
              onClick={() => scrollToSection('process')}
              className="py-2 font-medium hover:text-[#2073C7] transition-colors"
            >
              Process
            </button>
            <button 
              onClick={() => scrollToSection('benefits')}
              className="py-2 font-medium hover:text-[#2073C7] transition-colors"
            >
              Benefits
            </button>
            <Button 
              onClick={() => scrollToSection('cta')}
              variant="primary"
              size="full"
            >
              Book a Call
            </Button>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;