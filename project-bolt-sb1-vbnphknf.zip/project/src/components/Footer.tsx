import React from 'react';
import { Mail, Phone, MapPin } from 'lucide-react';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-gray-900 text-white py-12">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div>
            <h3 className="text-2xl font-extrabold tracking-tight text-[#329BFF] hover:scale-110 hover:brightness-110 transition-transform duration-200 cursor-pointer transform origin-left mb-2">
  SellSmarter<span className="text-white">.ai</span>
</h3>


            <p className="text-gray-400 mb-4 max-w-md">
              AI-powered automation solutions for retail and e-commerce businesses that want to scale without adding headcount.
            </p>
            <div className="flex flex-col space-y-2">
              <div className="flex items-center">
                <Mail size={16} className="mr-2 text-[#2073C7]" />
                <span className="text-gray-400">firdavs@sellsmarter.it.com</span>
              </div>
              <div className="flex items-center">
                <Phone size={16} className="mr-2 text-[#2073C7]" />
                <span className="text-gray-400">+998 90 526 03 40</span>
              </div>
              <div className="flex items-start">
                <MapPin size={16} className="mr-2 mt-1 text-[#2073C7]" />
                <span className="text-gray-400">Uzbekistan, Tashkent</span>
              </div>
            </div>
          </div>
          <div className="flex flex-col md:items-end">
            <h3 className="text-xl font-bold mb-4">Quick Links</h3>
            <div className="flex flex-col space-y-2">
              <button 
                onClick={() => document.getElementById('features')?.scrollIntoView({ behavior: 'smooth' })}
                className="text-gray-400 hover:text-[#2073C7] transition-colors text-left md:text-right"
              >
                Services
              </button>
              <button 
                onClick={() => document.getElementById('process')?.scrollIntoView({ behavior: 'smooth' })}
                className="text-gray-400 hover:text-[#2073C7] transition-colors text-left md:text-right"
              >
                Process
              </button>
              <button 
                onClick={() => document.getElementById('benefits')?.scrollIntoView({ behavior: 'smooth' })}
                className="text-gray-400 hover:text-[#2073C7] transition-colors text-left md:text-right"
              >
                Benefits
              </button>
              <button 
                onClick={() => document.getElementById('cta')?.scrollIntoView({ behavior: 'smooth' })}
                className="text-[#2073C7] hover:text-[#2073C7]/80 transition-colors font-medium text-left md:text-right"
              >
                Book a Free Strategy Call
              </button>
            </div>
          </div>
        </div>
        <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-500">
          <p>&copy; {currentYear} SellSmarter.ai. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;