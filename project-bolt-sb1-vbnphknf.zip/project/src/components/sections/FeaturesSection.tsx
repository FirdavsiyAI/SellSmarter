import React from 'react';
import SectionTitle from '../ui/SectionTitle';
import FeatureCard from '../ui/FeatureCard';
import ScrollReveal from '../ui/ScrollReveal';
import { MessageSquare, ShoppingCart, ArrowLeftRight, Cpu } from 'lucide-react';

const FeaturesSection: React.FC = () => {
  const features = [
    {
      icon: MessageSquare,
      title: 'Smart Chatbots',
      description: 'Lead capture, FAQs, and order tracking systems that engage customers 24/7 without human intervention.'
    },
    {
      icon: ShoppingCart,
      title: 'Ecom Automation',
      description: 'Abandoned cart recovery, personalized product recommendations, and seamless checkout experiences.'
    },
    {
      icon: ArrowLeftRight,
      title: 'Return & Support Flows',
      description: 'Form-based returns with auto-replies, saving your team hours of repetitive support tasks.'
    },
    {
      icon: Cpu,
      title: 'Custom AI Workflows',
      description: 'Custom automation for any repetitive process in your business operations or customer journey.'
    }
  ];

  return (
    <section id="features" className="py-24 bg-gray-50">
      <div className="container mx-auto px-4 md:px-6">
        <ScrollReveal>
          <SectionTitle 
            title="What Can I Automate for You?" 
            subtitle="AI solutions custom-built for your retail or e-commerce business"
            centered
          />
        </ScrollReveal>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <ScrollReveal key={index} delay={300 + index * 100}>
              <FeatureCard 
                icon={feature.icon}
                title={feature.title}
                description={feature.description}
              />
            </ScrollReveal>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturesSection;