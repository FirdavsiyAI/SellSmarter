import React from 'react';
import Button from '../ui/Button';
import ScrollReveal from '../ui/ScrollReveal';

const CtaSection: React.FC = () => {
  return (
    <section id="cta" className="py-24 bg-gradient-to-r from-[#2073C7] to-[#2073C7]/80 text-white">
      <div className="container mx-auto px-4 md:px-6">
        <div className="max-w-3xl mx-auto text-center">
          <ScrollReveal>
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              Let's See What We Can Automate in Your Business
            </h2>
            <p className="text-xl opacity-90 mb-8">
              Take the first step toward more efficiency, better customer experience, and increased sales.
            </p>
            <Button 
              variant="secondary" 
              size="lg"
              className="shadow-xl hover:shadow-2xl hover:-translate-y-1"
            >
              Book a Free Strategy Call
            </Button>
            <p className="mt-4 text-sm opacity-80">
              No pressure — just a quick 10-min chat to find automation opportunities.
            </p>
          </ScrollReveal>
        </div>
      </div>
    </section>
  );
};

export default CtaSection;