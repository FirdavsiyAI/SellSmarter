import React from 'react';
import Button from '../ui/Button';
import { ArrowDown } from 'lucide-react';
import ScrollReveal from '../ui/ScrollReveal';

const HeroSection: React.FC = () => {
  const scrollToProcess = () => {
    document.getElementById('process')?.scrollIntoView({ behavior: 'smooth' });
  };

  const scrollToCta = () => {
    document.getElementById('cta')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="relative min-h-screen flex items-center pt-20 overflow-hidden">
      {/* Background pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute -top-24 -right-24 w-96 h-96 bg-[#2073C7] rounded-full blur-3xl"></div>
        <div className="absolute top-1/2 -left-24 w-80 h-80 bg-indigo-500 rounded-full blur-3xl"></div>
      </div>

      <div className="container mx-auto px-4 md:px-6 py-12 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <ScrollReveal delay={300}>
              <span className="inline-block bg-[#2073C7]/10 text-[#2073C7] px-4 py-1 rounded-full text-sm font-medium mb-6">
                AI Automation Expert
              </span>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-6">
                Automate Repetitive Work in Your Retail Business — 
                <span className="text-[#2073C7]">Without Hiring More People</span>
              </h1>
              <p className="text-xl text-gray-600 mb-8 max-w-xl">
                AI-powered systems that handle customer support, lead capture, product questions & more — on autopilot.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button onClick={scrollToCta} size="lg">
                  Book a Free Strategy Call
                </Button>
                <Button onClick={scrollToProcess} variant="outline" size="lg">
                  See How It Works
                  <ArrowDown size={16} className="ml-2" />
                </Button>
              </div>
            </ScrollReveal>
          </div>
          
          <div className="hidden lg:block">
            <ScrollReveal direction="left" delay={600}>
              <div className="relative">
                <div className="aspect-[4/3] rounded-lg bg-gradient-to-br from-gray-900 to-gray-800 p-8 flex items-center justify-center shadow-xl relative overflow-hidden">
                  {/* Abstract AI visualization representation */}
                  <div className="absolute inset-0 opacity-30 overflow-hidden">
                    <div className="absolute top-0 left-0 w-full h-full">
                      {Array.from({ length: 10 }).map((_, i) => (
                        <div 
                          key={i}
                          className="absolute bg-[#2073C7]"
                          style={{
                            top: `${Math.random() * 100}%`,
                            left: `${Math.random() * 100}%`,
                            width: `${Math.random() * 3 + 1}px`,
                            height: `${Math.random() * 100 + 50}px`,
                            opacity: Math.random() * 0.5 + 0.2,
                            animation: `pulse ${Math.random() * 4 + 3}s infinite alternate`
                          }}
                        />
                      ))}
                    </div>
                  </div>
                  
                  <div className="relative z-10 text-center">
                    <div className="w-32 h-32 rounded-full bg-[#2073C7] mx-auto mb-8 flex items-center justify-center">
                      <svg width="64" height="64" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M12 2L2 7L12 12L22 7L12 2Z" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                        <path d="M2 17L12 22L22 17" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                        <path d="M2 12L12 17L22 12" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                      </svg>
                    </div>
                    <h3 className="text-xl font-bold text-white mb-2">AI-Powered Automation</h3>
                    <p className="text-gray-300">Working 24/7 so you don't have to</p>
                  </div>
                </div>
                
                {/* Decoration elements */}
                <div className="absolute -top-6 -right-6 w-12 h-12 bg-[#2073C7] rounded-lg shadow-lg"></div>
                <div className="absolute -bottom-6 -left-6 w-12 h-12 bg-[#2073C7] rounded-lg shadow-lg"></div>
              </div>
            </ScrollReveal>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;