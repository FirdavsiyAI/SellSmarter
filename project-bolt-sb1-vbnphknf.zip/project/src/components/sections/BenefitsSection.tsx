import React from 'react';
import SectionTitle from '../ui/SectionTitle';
import ScrollReveal from '../ui/ScrollReveal';
import { UserPlus, Clock, Briefcase, DollarSign } from 'lucide-react';

const BenefitsSection: React.FC = () => {
  const benefits = [
    {
      icon: UserPlus,
      title: 'Capture more leads without extra effort',
      description: 'Never miss a potential customer again. AI responds instantly, 24/7.'
    },
    {
      icon: Clock,
      title: 'Respond instantly to common customer questions',
      description: 'No more waiting. Customers get immediate answers to their most frequent questions.'
    },
    {
      icon: Briefcase,
      title: 'Reduce your team\'s workload',
      description: 'Let your team focus on high-value tasks while automation handles the repetitive ones.'
    },
    {
      icon: DollarSign,
      title: 'Close more sales from traffic you\'re already getting',
      description: 'Convert more visitors by engaging them at exactly the right moment.'
    }
  ];

  return (
    <section id="benefits" className="py-24 bg-white">
      <div className="container mx-auto px-4 md:px-6">
        <ScrollReveal>
          <SectionTitle 
            title="Why Automate?" 
            subtitle="The business advantages of AI-powered automation"
            centered
          />
        </ScrollReveal>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          {benefits.map((benefit, index) => {
            const Icon = benefit.icon;
            
            return (
              <ScrollReveal key={index} delay={300 + index * 100}>
                <div className="flex p-6 bg-gray-50 rounded-lg">
                  <div className="mr-4 text-[#2073C7]">
                    <Icon size={24} />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold mb-2">{benefit.title}</h3>
                    <p className="text-gray-600">{benefit.description}</p>
                  </div>
                </div>
              </ScrollReveal>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default BenefitsSection;