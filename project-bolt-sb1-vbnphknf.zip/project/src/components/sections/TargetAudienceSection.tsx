import React from 'react';
import SectionTitle from '../ui/SectionTitle';
import ScrollReveal from '../ui/ScrollReveal';
import { CheckCircle } from 'lucide-react';

const TargetAudienceSection: React.FC = () => {
  const targetPoints = [
    'You run or manage an online store',
    'You get the same customer questions over and over',
    'You want more sales without more staff',
    'You\'re tired of leads slipping through the cracks'
  ];

  return (
    <section className="py-24 bg-white">
      <div className="container mx-auto px-4 md:px-6">
        <div className="max-w-4xl mx-auto">
          <ScrollReveal>
            <SectionTitle 
              title="This is for you if..." 
              centered
            />
          </ScrollReveal>
          
          <div className="space-y-6">
            {targetPoints.map((point, index) => (
              <ScrollReveal key={index} delay={300 + index * 100}>
                <div className="flex items-start bg-gray-50 p-6 rounded-lg">
                  <CheckCircle className="text-amber-500 mr-4 flex-shrink-0 mt-1" size={24} />
                  <p className="text-xl">{point}</p>
                </div>
              </ScrollReveal>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default TargetAudienceSection;