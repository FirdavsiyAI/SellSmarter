import React from 'react';
import SectionTitle from '../ui/SectionTitle';
import ScrollReveal from '../ui/ScrollReveal';
import { Phone, ArrowRight, Settings, Coffee } from 'lucide-react';

const ProcessSection: React.FC = () => {
  const steps = [
    {
      icon: Phone,
      title: 'Discovery Call',
      description: 'You tell me what takes up your time and where you need help automating.'
    },
    {
      icon: Settings,
      title: 'I Build',
      description: 'I create and deploy the automation system tailored to your specific needs.'
    },
    {
      icon: Coffee,
      title: 'You Relax',
      description: 'The system runs 24/7 while you focus on growing your business.'
    }
  ];

  return (
    <section id="process" className="py-24 bg-gray-50">
      <div className="container mx-auto px-4 md:px-6">
        <ScrollReveal>
          <SectionTitle 
            title="How It Works" 
            subtitle="Three simple steps to automate your business processes"
            centered
          />
        </ScrollReveal>
        
        <div className="max-w-5xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {steps.map((step, index) => {
              const Icon = step.icon;
              
              return (
                <ScrollReveal key={index} delay={300 + index * 150}>
                  <div className="relative">
                    <div className="flex flex-col items-center text-center">
                      <div className="w-16 h-16 bg-[#2073C7] rounded-full flex items-center justify-center text-white mb-6">
                        <Icon size={24} />
                      </div>
                      <h3 className="text-2xl font-bold mb-4">{step.title}</h3>
                      <p className="text-gray-600">{step.description}</p>
                    </div>
                    
                    {index < steps.length - 1 && (
                      <div className="hidden md:block absolute top-8 left-full transform -translate-x-1/2">
                        <ArrowRight className="text-gray-300" size={28} />
                      </div>
                    )}
                  </div>
                </ScrollReveal>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};

export default ProcessSection;